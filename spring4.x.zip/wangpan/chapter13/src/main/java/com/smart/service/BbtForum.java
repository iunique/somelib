package com.smart.service;

import com.smart.domain.Forum;

public interface BbtForum {
	void addForum(Forum forum);
}
