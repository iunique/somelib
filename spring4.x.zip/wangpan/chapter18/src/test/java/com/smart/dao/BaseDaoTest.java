package com.smart.dao;

import org.unitils.UnitilsTestNG;
import org.unitils.spring.annotation.SpringApplicationContext;

@SpringApplicationContext({"xiaochun-dao.xml"})
public class BaseDaoTest extends UnitilsTestNG{
	
}
