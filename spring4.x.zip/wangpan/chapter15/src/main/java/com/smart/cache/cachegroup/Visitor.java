package com.smart.cache.cachegroup;

import com.smart.cache.domain.User;

public class Visitor extends User {
    protected Visitor(String id, String name) {
        super(id, name);
    }
}
