package com.smart.dao.mybatis;

import com.smart.domain.Topic;

public interface TopicMybatisDao {
	void addTopic(Topic topic);
}
