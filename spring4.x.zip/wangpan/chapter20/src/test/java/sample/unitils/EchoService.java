package sample.unitils;

public class EchoService {
	
    public String getEchoMessage(){
       return "Hello unitls...";	
    }
}
